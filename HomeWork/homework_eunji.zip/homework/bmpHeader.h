#ifndef __BMP_FILE_H__
#define __BMP_FILE_H__

typedef struct __attribute__((__packed__)){
	unsigned short bfType;		// BM이라는 캐릭터형이 저장되어 있습니다.
	unsigned int bfSize;		// 파일의 전체 크기
	unsigned short bfReserved1;	// 사용하지 않습니다.
	unsigned short bfReserved2;	// 사용하지 않습니다.
	unsigned int bf0ffBits;		// 파일 시작 부분에서 실제 영상데이터가 존재하는 위치까지 바이트 단위의 거리
	}BITMAPFILEHEADER;

typedef struct{
	unsigned int biSize;		// 구조체의 크기
	unsigned int biWidth;		// 비트맵의 가로 크기
	unsigned int biHeight;		// 비트맵의 세로 크기
	unsigned short biPlanes;	// Plane수(1로 설정)
	unsigned short biBitCount;	// 한 픽셀당 비트수
	unsigned int biCompression;	// 압축 유무 플래그
	unsigned int SizeImage;		// 그림 데이터의 크기
	unsigned int biXPelsPerMeter;	// 한 픽셀당 가로 미터
	unsigned int biYPelsPerMeter;	// 한 픽셀당 세로 미터
	unsigned int biClrUsed;		// 그림에서 실제 사용되는 컬러 수
	unsigned int biClrImportant;	// 중요하게 사용되는 컬러
	}BITMAPINFOHEADER;
	
typedef struct{
	unsigned char rgbBlue;		// B성분(파랑)
	unsigned char rgbGreen;		// G성분(초록)
	unsigned char rgbRed;		// R성분(빨강)
	unsigned char rgbReserved;
	}RGBQUAD;

#endif
